```php
__debugInfo ( )
```

Returns debugging information about the current object.