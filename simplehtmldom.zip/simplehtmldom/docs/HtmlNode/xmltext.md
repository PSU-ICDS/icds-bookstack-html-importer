```php
xmltext ( ) : string
```

Returns the xml representation for the inner text of the current node as a CDATA section.