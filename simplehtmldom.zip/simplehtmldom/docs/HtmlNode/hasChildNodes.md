```php
hasChildNodes ( ) : bool
```

Returns true if the current node has one or more child nodes.