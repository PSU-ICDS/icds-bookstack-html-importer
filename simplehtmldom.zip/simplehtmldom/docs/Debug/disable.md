```php
Debug::disable ()
```

Globally disables debug messages.