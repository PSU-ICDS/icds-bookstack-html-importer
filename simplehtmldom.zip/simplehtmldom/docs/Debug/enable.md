```php
Debug::enable ()
```

Globally enables debug messages.