```php
Debug::log (string $message)
```

Logs a debug message if the debugger is enabled. Does nothing if the debugger is disabled.