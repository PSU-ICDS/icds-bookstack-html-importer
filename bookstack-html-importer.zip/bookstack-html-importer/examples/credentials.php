<?php

$credentials = array(
	'url' => "10.6.64.33",
	'id' => "WFFb7V15lqf2FEVsEsMj44N1oE9zTCSP",
	'secret' => "a7nQCadNxV0uhBp5owh5fLokujCDBImo"
);
